<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" name="viewport" />
  <meta http-equiv="Cache-Control" content="max-age=7200" />
  <meta http-equiv="Expires" content="Mon, 20 Jul 2013 23:00:00 GMT" />
  <title>HKID Scan demo</title>
  <style>

    :-webkit-direct-focus {
      border: 0 !important;
      outline: none !important;
    }
  </style>
  <link rel="shortcut icon" href="https://zh-hans.reactjs.org/favicon-32x32.png?v=f4d46f030265b4c48a05c999b8d93791" />
  <script src="https://unpkg.com/vconsole@latest/dist/vconsole.min.js">
  </script>
  <script>

    var vConsole = new window.VConsole();
  </script>
  <link href="css/index.css?ver=6" rel="stylesheet">
</head>

<body style="margin: 0 0 0 0;">
  <div id="root" style="width: 100%;
        height: 0px;
        position: relative;">
     
        </div>
  <div id="caparea" style=" width: 90%;

        position: absolute;
        top: 280px;
        left: 5%;">
    <img id="cap" style="width: 100%; opacity: 0.6;" src="img/step1w.png">
    <p id= 'captext'style="color:white; 
    font-size: 30px; 
    text-align:center; 
    vertical-align: middle;
    position: absolute; 
    width:100%;
    top:80px;
  left: 0%;
  aspect-ratio : 1 / 0.63;
  margin:0 0 0 0;"></p>
    <img id="img" style="width: 0%;" src="img/n1.png" hidden>
  </div>
  <div style=" background: rgba(0,0,0,1); height:200px;width: 100%; position: absolute; top:0;">
  <div id="img1div" style=" background: rgba(151,151,151,0.5);border-radius:10px;";>
  <p id= 'step1text'style="color:white; font-size: 30px; text-align:center;">Step 1</p>
    <img id="img1" style="width: 100%;" src="img/n1.png" hidden>
  </div>
  <div id="img2div" style=" background: rgba(151,151,151,0.5);border-radius:10px;";>
  <p id= 'step2text'style="color:white; font-size: 30px; text-align:center;">Step 2</p>
    <img id="img2" style="width: 100%;" src="img/n2.png" hidden>
  </div>
  <div id="img3div" style=" background: rgba(151,151,151,0.5);border-radius:10px;";>
  <p id= 'step3text'style="color:white; font-size: 30px; text-align:center;">Step 3</p>
    <img id="img3" style="width: 100%;" src="img/n3.png" hidden>
  </div>
</div>
  <div style=" width: 100%;
  height: 50px;
  position: absolute;
  top:100px;
  left: 0%;
  ">
    <p style="color:white; font-size: 30px; text-align:center; background: rgba(151,151,151,0.8);border-radius:10px;" id="resultString">System loading, Please wait.</p>
  </div>
  <div style=" background: rgba(0,0,0,1); width: 100%; height:120px; position: absolute;
  bottom: 0;
  left: 0;">
</div>
</body>
<script src="js/main.2998b3d76267f7f2f41b.js"></script>
<script>
  var sdk = new window.daLite({
    certiType: <?php echo $_GET['type'];?>,
    //rectangleContainer: document.body
    rectangleContainer: document.getElementById('caparea')
    //rectangleContainer:document.body
  })
  sdk.setup("assets/dalite_sim_next.onnx").then((data) => {//  Client
    console.log("data")
    console.log(data)
    document.getElementById("resultString").innerHTML = "Please scan the front of your HKID";  
    const devices = sdk.devices;
    console.log(devices)
    sdk.step = 1;
    if (data.success) {
      sdk.addListeners(daLite.type.RESULT, [function (message) {// subscribe to
        console.log("RESULT")
        console.log(message)
        console.log(message['step'])
        document.getElementById("captext").innerHTML = "";  
        //document.getElementById("resultString").innerHTML = message['message'];
        if(message['step'] == 1){
            document.getElementById("resultString").innerHTML = "Please scan the front of your HKID";  
        }else if(message['step'] == 2){
            document.getElementById("resultString").innerHTML = "Please scan the front of your HKID in a tilted position";  
        }else if(message['step'] == 3){
            document.getElementById("resultString").innerHTML = "Please scan the back of your HKID";  
        }
        if(message['code'] == "LESS_ROTATE"){
            document.getElementById("captext").innerHTML = "Tilt angle is too small";  
        }else if(message['code'] == "MORE_ROTATE"){
            document.getElementById("captext").innerHTML = "Tilt angle is too large";  
        }else if(message['code'] == "FAR"){
            document.getElementById("captext").innerHTML = "Move your HKID closer to the camera";  
        }else if(message['code'] == "MOREA"){
            document.getElementById("captext").innerHTML = "Place your HKID on a level surface";  
        }else if(message['code'] == "LIGHT"){
            document.getElementById("captext").innerHTML = "Too bright";  
        }else if(message['code'] == "DARK"){
            document.getElementById("captext").innerHTML = "Too dark";  
        }else if(message['code'] == "ERRORCERTI"){
            document.getElementById("captext").innerHTML = "Please provide your HKID";  
        }else if(message['code'] == "EXCEED_LEFT"){
            document.getElementById("captext").innerHTML = "Keep your HKID within the scan window";  
        }else if(message['code'] == "EXCEED_TOP"){
            document.getElementById("captext").innerHTML = "Keep your HKID within the scan window";  
        }else if(message['code'] == "EXCEED_RIGHT"){
            document.getElementById("captext").innerHTML = "Keep your HKID within the scan window";  
        }else if(message['code'] == "EXCEED_BOTTOM"){
            document.getElementById("captext").innerHTML = "Keep your HKID within the scan window";  
        }else if(message['code'] == "LOOSE"){
            document.getElementById("captext").innerHTML = "Unable to detect HKID";  
        }else if(message['code'] == "OK"){
            document.getElementById("captext").innerHTML = "Image captured";  
        }

        if (message['step'] == 1 && message['code'] == "OK") {
          console.log("Start step1")
          document.getElementById('img1').hidden = false;
          document.getElementById('step1text').hidden = true;
          document.getElementById('img1').src = message['preview'];
          document.getElementById("cap").src = "img/step2w.png";
        }else if (message['step'] == 2 && message['code'] == "OK") {
          console.log("Start step2")
          document.getElementById('img2').hidden = false;
          document.getElementById('step2text').hidden = true;
          document.getElementById('img2').src = message['preview'];
          document.getElementById("cap").src = "img/step1w.png";
        }else if (message['step'] == 3 && message['code'] == "OK") {
          console.log("Start step4")
          document.getElementById('img3').hidden = false;
          document.getElementById('step3text').hidden = true;
          document.getElementById('img3').src = message['preview'];

        }

      }])
      sdk.addListeners(daLite.type.NEXTSTEP, [function (message) {// subscribe to
        console.log("NEXTSTEP")
        console.log(message)
        console.log(message['step'])
        if(message['step'] == 1){
            document.getElementById("resultString").innerHTML = "Please scan the front of your HKID";  
        }else if(message['step'] == 2){
            document.getElementById("resultString").innerHTML = "Please scan the front of your HKID in a tilted position";  
        }else if(message['step'] == 3){
            document.getElementById("resultString").innerHTML = "Please scan the back of your HKID";  
        }

      }])
      sdk.start();//  start shooting
    } else {
      console.log("failed")
      console.log(data)
    }
  })
</script>

</html>