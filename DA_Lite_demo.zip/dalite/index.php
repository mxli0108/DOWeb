<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0" name="viewport" />
  <meta http-equiv="Cache-Control" content="max-age=7200" />
  <meta http-equiv="Expires" content="Mon, 20 Jul 2013 23:00:00 GMT" />
  <title>香港身份证识别demo</title>
  <style>
    body, html {
  height: 100%;
  margin: 0;
}
    .bg {
      margin: 0;
  /* The image used */
  background-image: url("img/background.png");

  /* Full height */
  height: 100%; 
  width: 100%;
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>

  <link href="css/index.css?ver=1" rel="stylesheet">
</head>

<body>
  <div class="bg">
    <div>
  <p style="color:white; font-size: 40px; text-align:center;margin: 0 0 0 0; padding-top:10px;">TU DA Lite demo</p>
  <p style="color:white; font-size: 30px; text-align:center;margin-top: 10px;">Please select HKID Type</p>
  </div>
  <div style=" text-align:center;" onclick="location.href='dalite.php?type=1';">
    <font style="color:white; font-size: 20px;">2003</font>
    <img id="img" style="width: 100%;" src="img/old_certificate.png">
  </div>
  <div style=" text-align:center;" onclick="location.href='dalite.php?type=2';">
    <font style="color:white; font-size: 20px;">2018</font>
    <img id="img2" style="width: 100%;" src="img/certificate.png">
  </div>       

  
  </div>
</body>


</html>